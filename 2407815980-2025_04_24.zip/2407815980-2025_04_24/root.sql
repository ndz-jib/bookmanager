CREATE TABLE edition(
	Edition_ID INT PRIMARY KEY,
	Title VARCHAR(255) NOT NULL,
	Author VARCHAR(255),
	cnt INT NOT NULL
) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;

CREATE TABLE reader(
	Reader_ID INT PRIMARY KEY,
	Pwd VARCHAR(255) DEFAULT NULL
) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;

CREATE TABLE borrow_record (
  Borrow_ID INT PRIMARY KEY,
  Edition_ID INT,
  Reader_ID INT,
  lend_time DATETIME NOT NULL,
  return_time DATETIME DEFAULT NULL,
  FOREIGN KEY (Edition_ID) REFERENCES edition(Edition_ID),
  FOREIGN KEY (Reader_ID) REFERENCES reader(Reader_ID)
) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;

ALTER TABLE reader ADD COLUMN User_Name VARCHAR(255) UNIQUE AFTER Reader_ID;

ALTER TABLE borrow_record MODIFY Borrow_ID INT AUTO_INCREMENT;

INSERT INTO reader VALUES (1,'admin','admin123');

INSERT INTO edition VALUES(1,'水浒传','施耐庵',90);
INSERT INTO edition VALUES(2,'三国演义','罗贯中',100);
INSERT INTO edition VALUES(3,'西游记','吴承恩',100);
INSERT INTO edition VALUES(4,'红楼梦','曹雪芹',80);

INSERT INTO borrow_record VALUES(1,2,1,'2025-04-23 17:48:10',NULL);
INSERT INTO borrow_record VALUES(2,3,1,'2025-04-23 17:48:10',NULL);
INSERT INTO borrow_record VALUES(3,3,2,'2025-04-23 17:48:10',NULL);

INSERT INTO borrow_record(Edition_ID, Reader_ID, lend_time, return_time) VALUES (2,2,'2025-04-23 17:48:11',NULL);

SELECT Record_ID, borrow_time FROM borrow_record WHERE Edition_ID = 3 AND Reader_ID = 2 AND return_time IS NULL ORDER BY borrow_time ASC LIMIT 1;






