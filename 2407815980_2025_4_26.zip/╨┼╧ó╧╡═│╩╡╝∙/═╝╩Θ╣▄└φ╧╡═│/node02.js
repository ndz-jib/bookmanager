require('dotenv').config();
const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');

const app = express();
const port = 3001;

// 数据库连接配置
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || 'haohao1102',
  database: process.env.DB_NAME || 'db01',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  namedPlaceholders: true
});

// 中间件
const allowedOrigins = [
  'http://localhost:3000',
  'http://localhost:3001',
  'http://localhost:3002',
  'null' // 允许 file:// 协议
];
app.use(cors({
  origin: 'allowedOrigins', // 明确指定前端地址
  methods: ['GET', 'POST', 'PUT', 'DELETE']         // 允许的HTTP方法
}));

app.use(express.json());
app.get('/test-db', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT 1 + 1 AS solution');
    res.json({ status: 'ok', result: rows[0].solution });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 搜索图书接口
app.post('/search', async (req, res) => {
	let connection;
  try {
    const { keyword } = req.body;
	if (!keyword || typeof keyword !== 'string') {
	  return res.status(400).json({ error: '无效的搜索关键词' });
	}
	
	connection = await pool.getConnection();
    
    const sql = `
      SELECT 
        Edition_ID AS id, 
        Title AS title, 
        Author AS author,
		cnt
      FROM edition 
      WHERE 
        Title LIKE :keyword OR 
        Author LIKE :keyword
    `;
    
    const [rows] = await connection.execute(sql, {
		keyword: `%${keyword.trim()}%`
    });

    connection.release();
    
    const result = rows.map(book => ({
	  ...book,
	  status: book.cnt > 0 ? '可借' : '已借完'
	}));

	res.json(result);

  } catch (error) {
    console.error('搜索错误:', error);
    res.status(500).json({ error: '服务器内部错误' });
  } finally {
	  if(connection)connection.release();
  }
});

// 借阅接口
app.post('/borrow', async (req, res) => {
    let connection;
    try {
        const { username, bookId, borrowDate } = req.body;
        if (!username || !bookId || !borrowDate) {
            return res.status(400).json({ success: false, message: '缺少必要参数' });
        }

        connection = await pool.getConnection();
        await connection.beginTransaction();

        // 验证图书可借状态
        const [books] = await connection.query(
            'SELECT * FROM edition WHERE Title = ? FOR UPDATE',
            [bookId]
        );
        
        if (books.length === 0) {
            return res.status(404).json({ success: false, message: '图书不存在' });
        }
        
        const book = books[0];
        if (book.available <= 0) {
            return res.status(400).json({ success: false, message: '该图书已无库存' });
        }

        // 减少库存
        await connection.query(
            'UPDATE edition SET cnt = cnt - 1 WHERE Title = ?',
            [bookId]
        );

        // 创建借阅记录
        await connection.query(
            `INSERT INTO borrow_record 
            (Edition_ID, Reader_ID, lend_time, return_time)
            VALUES (
                (SELECT Edition_ID FROM edition WHERE Title = ?),
                (SELECT Reader_ID FROM Reader WHERE User_Name = ?),
                ?,
                NULL
            )`,
            [bookId, username, borrowDate]
        );

        await connection.commit();
        res.json({ success: true, message: '借阅成功' });
    } catch (error) {
        if (connection) await connection.rollback();
        console.error('借阅错误:', error);
        res.status(500).json({
            success: false,
            message: error.message || '服务器错误'
        });
    } finally {
        if (connection) connection.end();
    }
});

// 归还接口
app.post('/return', async (req, res) => {
    let connection;
    try {
        const { username, bookId, returnDate } = req.body;
        if (!username || !bookId || !returnDate) {
            return res.status(400).json({ success: false, message: '缺少必要参数' });
        }

        connection = await pool.getConnection();
        await connection.beginTransaction();
		
		// 获取读者信息
		const [readers] = await connection.query(
			'SELECT Reader_ID FROM Reader WHERE User_Name = ? FOR UPDATE',
			[username]
		);
		if (readers.length === 0) {
			return res.status(404).json({ success: false, message: '用户不存在' });
		}
		const readerId = readers[0].Reader_ID;

        // 验证图书状态
        const [books] = await connection.query(
            'SELECT Edition_ID, cnt FROM edition WHERE Title = ? FOR UPDATE',
            [bookId]
        );
        
        if (books.length === 0) {
            return res.status(404).json({ success: false, message: '图书不存在' });
        }
        
        const book = books[0];
		
		// 查询可归还记录
		const [records] = await connection.query(
			`SELECT Borrow_ID, lend_time 
			 FROM borrow_record 
			 WHERE 
			   Edition_ID = ? AND 
			   Reader_ID = ? AND 
			   return_time IS NULL 
			 ORDER BY lend_time ASC 
			 LIMIT 1`,
			[book.Edition_ID, readerId]
		);

		if (records.length === 0) {
			return res.status(400).json({ 
				success: false, 
				message: '没有找到可归还的借阅记录' 
			});
		}
		
		// 日期验证
		const borrowDate = new Date(records[0].lend_time );
		const returnDateObj = new Date(returnDate);
		if (returnDateObj < borrowDate) {
			return res.status(400).json({ 
				success: false, 
				message: '归还日期不能早于借阅日期' 
			});
		}
		
		// 更新借阅记录
		await connection.query(
			'UPDATE borrow_record SET return_time = ? WHERE Borrow_ID = ?',
			[returnDate, records[0].Borrow_ID]
		);

        // 更新库存（确保不会超过总库存）
		const newCnt = book.cnt + 1;
		await connection.query(
			'UPDATE edition SET cnt = ? WHERE Edition_ID = ?',
			[Math.min(newCnt, 100), book.Edition_ID] // 确保库存不超总量
		);

        await connection.commit();
        res.json({ success: true, message: '归还成功' });
    } catch (error) {
        if (connection) await connection.rollback();
        console.error('归还错误:', error);
        res.status(500).json({
            success: false,
            message: error.message || '服务器错误'
        });
    } finally {
        if (connection) connection.release();
    }
});

// 添加图书接口
app.post('/api/books', async (req, res) => {
    try{
		const { title, author } = req.body;
		if (!title || !author) {
		    return res.status(400).json({ message: '书名和作者不能为空' });
		}
		
		connection = await pool.getConnection();
		await connection.beginTransaction();
		
		const [result] = await connection.query(
			'INSERT INTO edition (Title, Author,cnt) VALUES (?, ?, 100)', 
			[title, author],
		);
			
			await connection.commit();
		    res.json({ message: '图书添加成功', id: result.insertId });
	} catch(error) {
		if (connection) await connection.rollback();
		console.error('添加错误:', error);
		res.status(500).json({
		    success: false,
		    message: error.message || '服务器错误'
		});
	} finally {
		if(connection) connection.release();
	}
});

//添加用户接口
app.post('/api/users', async (req, res) => {
    try{
		const { user_name, password } = req.body;
		if (!user_name || !password) {
		    return res.status(400).json({ message: '用户名和密码不能为空' });
		}
		
		connection = await pool.getConnection();
		await connection.beginTransaction();
		
		const [result] = await connection.query(
			'INSERT INTO reader (User_Name, Pwd) VALUES (?, ?)', 
			[user_name, password],
		);
			
			await connection.commit();
		    res.json({ message: '用户添加成功', id: result.insertId });
	} catch(error) {
		if (connection) await connection.rollback();
		console.error('添加错误:', error);
		res.status(500).json({
		    success: false,
		    message: error.message || '服务器错误'
		});
	} finally {
		if(connection) connection.release();
	}
});

// 搜索用户接口
app.post('/search_user', async (req, res) => {
	let connection;
  try {
    const { keyword } = req.body;
	if (!keyword || typeof keyword !== 'string') {
	  return res.status(400).json({ error: '无效的搜索关键词' });
	}
	
	connection = await pool.getConnection();
    
    const sql = `
      SELECT 
        Reader_ID AS id, 
        User_Name AS user_name, 
        Pwd AS password
      FROM reader 
      WHERE 
        User_Name LIKE :keyword OR 
        Pwd LIKE :keyword
    `;
    
    const [rows] = await connection.execute(sql, {
		keyword: `%${keyword.trim()}%`
    });

    connection.release();
    
    const result = rows.map(user => ({
	  ...user
	}));

	res.json(result);

  } catch (error) {
    console.error('搜索错误:', error);
    res.status(500).json({ error: '服务器内部错误' });
  } finally {
	  if(connection)connection.release();
  }
});

// 借阅记录查询接口
app.get('/borrow-records', async (req, res) => {
	try {
		const username = req.query.username;
		if (!username) {
		  return res.status(400).json({ error: '缺少用户名参数' });
		}
		const query = `
		    SELECT 
		        Title AS book_title,
		        DATE_FORMAT(lend_time, '%Y-%m-%d') AS borrow_date,
				DATE_FORMAT(return_time, '%Y-%m-%d') AS return_date,
		        CASE 
		            WHEN return_time IS NULL THEN '在借'
		            ELSE '已归还'
		        END AS status
		    FROM borrow_record
		    JOIN reader ON reader.Reader_ID = borrow_record.Reader_ID
			JOIN edition ON edition.Edition_ID = borrow_record.Edition_ID
		    WHERE reader.User_Name = ?
		`;
		const [results] = await pool.query(query, [username]);
		res.json(results);
		// pool.query(query, [username], (error, results) => {
		//     if (error) {
		//         console.error('数据库查询错误:', error);
		//         return res.status(500).json({ error: '数据库查询失败' });
		//     }
		//     res.json(results);
		// });
	} catch (error) {
		console.error('数据库查询错误:', error);
		res.status(500).json({ error: '数据库查询失败' });
	}
});

// 启动服务器
app.listen(port, () => {
  console.log(`服务器运行在 http://localhost:${port}`);
});