const express = require('express');
const cors = require('cors');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

// 数据库配置
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',     // 修改为你的数据库用户名
    password: 'haohao1102', // 修改为你的数据库密码
    database: 'db01'  // 修改为你的数据库名称
});

// 连接数据库
db.connect((err) => {
    if (err) throw err;
    console.log('Connected to database');
});

app.use(bodyParser.json());

// 允许所有来源（仅限开发环境）
app.use(cors({
  origin: true,          // 动态匹配请求来源
  credentials: true      // 允许发送 Cookie
}));

// 登录接口
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    
    // 使用预处理语句防止SQL注入
    const query = 'SELECT * FROM reader WHERE User_Name = ? AND Pwd = ?';
    
    db.query(query, [username, password], (err, results) => {
        if (err) {
            console.error('数据库查询错误:', err);
            return res.status(500).json({ success: false });
        }

        if (results.length > 0) {
            res.json({ success: true });
        } else {
            res.json({ success: false });
        }
    });
});

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});