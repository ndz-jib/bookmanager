require('dotenv').config();
const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');

const app = express();
const port = 3001;

// 数据库连接配置
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || 'haohao1102',
  database: process.env.DB_NAME || 'db01',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  namedPlaceholders: true
});

// 中间件
app.use(cors({
  origin: '*', // 明确指定前端地址
  methods: ['GET', 'POST', 'PUT', 'DELETE']         // 允许的HTTP方法
}));
const allowedOrigins = [
  'http://localhost:3000',
  'http://localhost:3001',
  'null' // 允许 file:// 协议
];
app.use(express.json());
app.get('/test-db', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT 1 + 1 AS solution');
    res.json({ status: 'ok', result: rows[0].solution });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 搜索接口
app.post('/search', async (req, res) => {
  try {
    const { keyword } = req.body;
	if (!keyword || typeof keyword !== 'string') {
	  return res.status(400).json({ error: '无效的搜索关键词' });
	}
    const connection = await pool.getConnection();
    
    const sql = `
      SELECT 
        Edition_ID AS id, 
        Title AS title, 
        Author AS author,
		cnt
      FROM edition 
      WHERE 
        Title LIKE :keyword OR 
        Author LIKE :keyword
    `;
    
    const [rows] = await connection.execute(sql, {
		keyword: `%${keyword.trim()}%`
    });

    connection.release();
    
    const result = rows.map(book => ({
	  ...book,
	  status: book.cnt > 0 ? '可借' : '已借完'
	}));

	res.json(result);

  } catch (error) {
    console.error('搜索错误:', error);
    res.status(500).json({ error: '服务器内部错误' });
  }
});

// 启动服务器
app.listen(port, () => {
  console.log(`服务器运行在 http://localhost:${port}`);
});