CREATE TABLE edition(
	Edition_ID INT PRIMARY KEY,
	Title VARCHAR(255) NOT NULL,
	Author VARCHAR(255),
	cnt INT NOT NULL
) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;

CREATE TABLE reader(
	Reader_ID INT PRIMARY KEY,
	Pwd VARCHAR(255) DEFAULT NULL
) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;

CREATE TABLE borrow_record (
  Borrow_ID INT PRIMARY KEY,
  Edition_ID INT,
  Reader_ID INT,
  lend_time DATETIME NOT NULL,
  return_time DATETIME DEFAULT NULL,
  FOREIGN KEY (Edition_ID) REFERENCES edition(Edition_ID),
  FOREIGN KEY (Reader_ID) REFERENCES reader(Reader_ID)
) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;

ALTER TABLE reader ADD COLUMN User_Name VARCHAR(255) UNIQUE AFTER Reader_ID;

INSERT INTO reader VALUES (1,'admin','admin123');

INSERT INTO edition VALUES(1,'水浒传','施耐庵',90);
INSERT INTO edition VALUES(2,'三国演义','罗贯中',100);
INSERT INTO edition VALUES(3,'西游记','吴承恩',110);
INSERT INTO edition VALUES(4,'红楼梦','曹雪芹',80);
SELECT * FROM reader;
COMMIT