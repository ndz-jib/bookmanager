// node3.js
require('dotenv').config();
const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');

const app = express();
const port = 3002; // 修改端口避免冲突

// 数据库连接配置（保持与node02.js相同）
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '1234',
  database: process.env.DB_NAME || 'db01',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  namedPlaceholders: true
});

// 中间件配置
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE']
}));
const allowedOrigins = [
  'http://localhost:3000',
  'http://localhost:3001',
  'http://localhost:3002',
  'null' // 允许 file:// 协议
];
app.use(express.json());

// 新增管理密钥验证接口
app.post('/admin/verify', async (req, res) => {
  try {
    const { secretKey } = req.body;

    if (!secretKey) {
      return res.status(400).json({ success: false, message: "需要提供密钥" });
    }

    if (secretKey === 'admin123') {
      res.json({ 
        success: true,
        redirectUrl: "/图书管理系统/3.html" // 或返回管理接口令牌
      });
    } else {
      res.status(401).json({ 
        success: false,
        message: "无效的管理密钥" 
      });
    }

  } catch (error) {
    console.error('验证失败:', error);
    res.status(500).json({ 
      success: false,
      message: "服务器内部错误" 
    });
  }
});

// 保留原有搜索接口（根据需要可以删除）
app.post('/search', async (req, res) => { /* ... */ });

// 启动服务器
app.listen(port, () => {
  console.log(`管理服务器运行在 http://localhost:${port}`);
});